#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

compderror<-function(expectanalytic_error=NULL,expecttrue_error=NULL,expectboot_error=NULL,SWA1_error=NULL,median1_error=NULL,mx1_error=NULL,quatileexpectanalytic_error=NULL,
                     quatileexpecttrue_error=NULL,quatileexpectboot_error=NULL,expectanalytic=NULL,expecttrue=NULL,expectboot=NULL,SWA1=NULL,median1=NULL,mx1=NULL,quatileexpectanalytic=NULL,
                     quatileexpecttrue=NULL,quatileexpectboot=NULL){
  mx2_error=0
  mx2=1/2

  dqm1boot<-(abs(1/(mx1-mx2))^2)*(quatileexpectboot_error^2)+(mx1_error^2)*((abs(-((quatileexpectboot-mx1)/((mx1-mx2)^2))-(1/(mx1-mx2))))^2)
  dqm1analytic<-(abs(1/(mx1-mx2))^2)*(quatileexpectanalytic_error^2)+(mx1_error^2)*((abs(-((quatileexpectanalytic-mx1)/((mx1-mx2)^2))-(1/(mx1-mx2))))^2)
  dqm1true<-(abs(1/(mx1-mx2))^2)*(quatileexpecttrue_error^2)+(mx1_error^2)*((abs(-((quatileexpecttrue-mx1)/((mx1-mx2)^2))-(1/(mx1-mx2))))^2)

  drm1boot<-(abs(-(expectboot-SWA1)/((SWA1-median1)^2)-1/(SWA1-median1))^2)*(SWA1_error^2)+((abs((expectboot-SWA1)/((SWA1-median1)^2)))^2)*(median1_error^2)
  drm1analytic<-(abs(-(expectanalytic-SWA1)/((SWA1-median1)^2)-1/(SWA1-median1))^2)*(SWA1_error^2)+((abs((expectanalytic-SWA1)/((SWA1-median1)^2)))^2)*(median1_error^2)
  drm1true<-(abs(-(expecttrue-SWA1)/((SWA1-median1)^2)-1/(SWA1-median1))^2)*(SWA1_error^2)+((abs((expecttrue-SWA1)/((SWA1-median1)^2)))^2)*(median1_error^2)

  listd<-c(drm1analytic=sqrt(drm1analytic),drm1true=sqrt(drm1true),drm1boot=sqrt(drm1boot),dqm1analytic=sqrt(dqm1analytic),dqm1true=sqrt(dqm1true),dqm1boot=sqrt(dqm1boot))
  return(listd)
}
