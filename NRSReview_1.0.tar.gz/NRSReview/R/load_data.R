#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.
data(Imoments_values, package = "NRSReview")
data(I_values, package = "NRSReview")
data(d_values, package = "NRSReview")
data(quasiuni_2_104, package = "NRSReview")
data(quasiuni_3_104, package = "NRSReview")
data(quasiuni_4_104, package = "NRSReview")
data(quasiuni_5_104, package = "NRSReview")
