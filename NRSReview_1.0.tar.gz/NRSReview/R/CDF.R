#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

CDF<-function(x,xevaluated,sorted=FALSE){
  if(sorted){
    sortedx<-x
  }else{

    sortedx<-Rfast::Sort(x,descending=FALSE,partial=NULL,stable=FALSE,na.last=NULL)
  }
  lengthx<-length(x)
  quantile2<-min(which(sortedx>(xevaluated)))
  if(is.infinite(quantile2)){
    quantile2=length(sortedx)
  }
  sortedquantile2<-sortedx[quantile2]
  sortedquantile21<-sortedx[quantile2-1]
  if(quantile2==1){
    sortedquantile21<-sortedx[quantile2]
  }
  if(sortedquantile21==sortedquantile2){
    result<-(quantile2-1)/lengthx
  }else{
    result<-((xevaluated-sortedquantile21)/(sortedquantile2-sortedquantile21)+quantile2-1)/lengthx
  }
  if(result>1){
    return(1)
  }else if (result<0){
    return(0)
  }else{
    return(result)
  }
}

