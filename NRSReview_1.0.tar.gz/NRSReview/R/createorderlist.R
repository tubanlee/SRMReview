#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.


createorderlist<-function(quni1,size,interval,dimension){
  orderlist1<-batchapply1Cpp(quni1,dimension,size)
  removelist(orderlist1,interval=interval)
}

removelist<-function(orderlist1,interval=8){
  orderlist1<-orderlist1[!duplicated(orderlist1), ]
  rowsum1<-Rfast::rowsums(orderlist1)
  orderlist1<-orderlist1[rowsum1>0,]
  reminder1<-(length(orderlist1[,1])%%interval)
  if (reminder1==0){
    return(orderlist1)
  }else{
    orderlist1<-orderlist1[-c(1:reminder1),]
    return(orderlist1)
  }
}
