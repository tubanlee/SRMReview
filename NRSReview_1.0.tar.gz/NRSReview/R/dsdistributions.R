#Copyright 2023 Tuban Lee
#This is a test package that is currently under review in PNAS, please do not share it.

#The Beta Distribution
rPareto<-function(n,shape, scale) {
  uni<-runif(n)
  sample1<-dsPareto(uni,shape, scale)
  sample1
}
#The Beta Distribution
dsbeta<-function(uni,shape1, shape2, ncp = 0, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qbeta(uni,shape1, shape2, ncp, lower.tail, log.p)
  sample1
}
#The Binomial Distribution
dsbinom<-function(uni,size, prob,lower.tail = TRUE, log.p = FALSE) {
  sample1<-qbinom(uni,size, prob,lower.tail, log.p)
  sample1
}
#The Cauchy Distribution
dscauchy<-function(uni,location=0, scale = 1, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qcauchy(uni,location,scale, lower.tail, log.p)
  sample1
}
#The (non-central) Chi-Squared Distribution
dschisq<-function(uni,df,ncp=0,lower.tail=TRUE,log.p = FALSE) {
  sample1<-qchisq(uni,df,ncp,lower.tail, log.p)
  sample1
}
#The Exponential Distribution
dsexp<-function (uni,rate = 1, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qexp(uni,rate, lower.tail, log.p)
  sample1
}
#The F Distribution
dsf<-function (uni,df1, df2, ncp, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qf(uni,df1, df2, ncp, lower.tail, log.p)
  sample1
}
#The Gamma Distribution
dsgamma<-function (uni,shape, rate = 1, scale = 1/rate, lower.tail = TRUE,log.p = FALSE){
  sample1<-qgamma(uni,shape, rate, scale, lower.tail,log.p)
  sample1
}
#The Geometric Distribution
dsgeom<-function (uni,prob, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qgeom(uni,prob, lower.tail, log.p)
  sample1
}
#The Hypergeometric Distribution
dshyper<-function (uni,m, n, k, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qhyper(uni,m, n, k, lower.tail, log.p)
  sample1
}
#The Log Normal Distribution
dslnorm<-function (uni,meanlog = 0, sdlog = 1, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qlnorm(uni,meanlog, sdlog, lower.tail, log.p)
  sample1
}
#The Logistic Distribution
dslogis<-function (uni,location = 0, scale = 1, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qlogis(uni,location, scale, lower.tail, log.p)
  sample1
}
#The Negative Binomial Distribution
dsnbinom<-function (uni,size, prob, mu, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qnbinom(uni, size, prob, mu, lower.tail, log.p)
  sample1
}
#The Normal Distribution
dsnorm<-function (uni,mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qnorm(uni,mean, sd , lower.tail, log.p)
  sample1
}
#The Poisson Distribution
dspois<-function (uni,lambda, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qpois(uni, lambda, lower.tail, log.p)
  sample1
}
#The Student t Distribution
dst<-function (uni,df, ncp, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qt(uni,df, ncp, lower.tail, log.p)
  sample1
}
#The Uniform Distribution
dsunif<-function (uni,min = 0, max = 1, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qunif(uni,min, max, lower.tail, log.p)
  sample1
}
#The Weibull Distribution
dsWeibull<-function (uni,shape, scale = 1, lower.tail = TRUE, log.p = FALSE){
  sample1<-qweibull(uni,shape, scale,lower.tail,log.p)
  sample1
}
#Distribution of the Wilcoxon Rank Sum Statistic
dswilcox<-function (uni, m, n, lower.tail = TRUE, log.p = FALSE) {
  sample1<-qwilcox(uni,  m, n, lower.tail, log.p)
  sample1
}
#The generalized Gaussian distribution
dsgnorm<-function (uni,shape, scale = 1){
  sample1<-qgnorm(p=uni, mu = 0, alpha = scale, beta = shape)
  sample1
}
rgnorm<-function (n,shape, scale = 1){
  uni<-runif(n)
  sample1<-dsgnorm(uni,shape, scale)
  sample1
}
